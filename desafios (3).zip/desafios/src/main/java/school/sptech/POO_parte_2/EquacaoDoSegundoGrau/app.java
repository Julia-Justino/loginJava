package school.sptech.POO_parte_2.EquacaoDoSegundoGrau;

public class app {
    public static void main(String[] args) {
        EquacaoDoSegundoGrau eq1 = new EquacaoDoSegundoGrau(1.0,-1.0, -30.0);

        eq1.calcularRaizes();
    }
}
